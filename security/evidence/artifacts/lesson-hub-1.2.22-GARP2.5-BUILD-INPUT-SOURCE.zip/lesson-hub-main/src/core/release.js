export const APP_RELEASE = Object.freeze({
  appId: 'lesson-hub',
  version: '1.2.22',
  schema: 'ai-studio-app-manifest-v1',
  status: 'Připraveno k řízenému pilotu',
  releasedAt: '2026-09-10',
});
